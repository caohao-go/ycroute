<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/**
 * Util_Sample Class
 *
 * @package        SuperCI
 * @subpackage    Library
 * @category      Util_Sample Library
 * @author        caohao
 */
class Util_Sample
{
    public function getInfo() {
        return "my library Util_Sample";
    }
}