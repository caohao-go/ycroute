<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/**
 * Sample Class
 *
 * @package        SuperCI
 * @subpackage    Library
 * @category      Sample Library
 * @author        caohao
 */
class Sample
{
    public function getInfo() {
        return "my library Sample";
    }
}