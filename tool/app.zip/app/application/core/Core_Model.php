<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * ExampleModel Class
 *
 * @package        SuperCI
 * @subpackage    Model
 * @category      Example Model
 * @author        caohao
 */
class Core_Model {
    var $db;
    const EMPTY_STRING = -999999999;

    public function __construct() {
        $this->util_log = Logger::get_instance('model_log');
    }

    /**
     * 根据key获取表记录
     * @param string redis_key redis 缓存键值
     */
    private function get_redis($redis_key) {
        if (empty($redis_key)) return;

        $redis = Loader::redis("default");
        if (!empty($redis)) {
            return $redis->get($redis_key);
        }
    }

    /**
     * 设置 redis 值
     * @param string redis_key redis 缓存键值, 可空， 非空时清理键值缓存
     * @param array data 表数据
     * @param int redis_expire redis 缓存到期时长(秒)
     * @param boolean set_empty_flag 是否缓存空值，如果缓存空值，在表记录更新之后，一定记得清理空值标记缓存
     */
    private function set_redis($redis_key, $data, $redis_expire, $set_empty_flag) {
        if (empty($redis_key)) return;

        $redis = Loader::redis("default");
        if (!empty($redis)) {
            if (empty($data) && $set_empty_flag) {
                $redis->set($redis_key, self::EMPTY_STRING);
            } else {
                $redis->set($redis_key, serialize($data));
            }
            $redis->expire($redis_key, $redis_expire);
        }
    }

    /**
     * 清理记录缓存
     * @param string redis_key redis 缓存键值
     */
    public function clear_redis_cache($redis_key = "") {
        if (empty($redis_key)) {
            return;
        }

        $redis = Loader::redis("default");
        if (!empty($redis)) {
            $redis->del($redis_key);
        }
    }

    /**
     * 插入表记录
     * @param string table 表名
     * @param array data 表数据
     * @param string redis_key redis 缓存键值, 可空， 非空时清理键值缓存
     */
    public function insert_table($table, $data, $redis_key = "") {
        $ret = $this->db->insert($table, $data);

        if (!empty($redis_key)) {
            $this->clear_redis_cache($redis_key);
        }

        if ($ret) {
            return true;
        } else {
            $this->trade_log->LogError("error to insert_table $table , DATA=[".json_encode($data)."]");
            return false;
        }
    }

    /**
     * 更新表记录
     * @param string table 表名
     * @param array where 查询条件
     * @param array data 更新数据
     * @param string redis_key redis 缓存键值, 可空， 非空时清理键值缓存
     */
    public function update_table($table, $where, $data, $redis_key = "") {
        if (empty($where)) return;
        $ret = $this->db->where($where)->update($table, $data);

        if (!empty($redis_key)) {
            $this->clear_redis_cache($redis_key);
        }

        if ($ret) {
            return true;
        } else {
            $this->trade_log->LogError("error to update_table $table [".json_encode($where)."], DATA=[".json_encode($data)."]");
            return false;
        }
    }

    /**
     * 替换表记录
     * @param string table 表名
     * @param array data 替换数据
     * @param string redis_key redis 缓存键值, 可空， 非空时清理键值缓存
     */
    public function replace_table($table, $data, $redis_key = "") {
        $ret = $this->db->replace($table, $data);

        if (!empty($redis_key)) {
            $this->clear_redis_cache($redis_key);
        }

        if ($ret) {
            return true;
        } else {
            $this->trade_log->LogError("error to replace_table $table , DATA=[".json_encode($data)."]");
            return false;
        }
    }

    /**
     * 删除表记录
     * @param string table 表名
     * @param array where 查询条件
     * @param string redis_key redis缓存键值, 可空， 非空时清理键值缓存
     */
    public function delete_table($table, $where, $redis_key = "") {
        if (empty($where)) return;
        $ret = $this->db->where($where)->delete($table);

        if (!empty($redis_key)) {
            $this->clear_redis_cache($redis_key);
        }

        if ($ret) {
            return true;
        } else {
            $this->trade_log->LogError("error to delete_table $table [".json_encode($where)."]");
            return false;
        }
    }
    /**
     * 根据key获取表记录
     * @param string table 表名
     * @param string key 键名
     * @param string value 键值
     * @param string redis_key redis 缓存键值, 可空， 非空时清理键值缓存
     * @param int redis_expire redis 缓存到期时长(秒)
     * @param boolean set_empty_flag 是否标注空值，如果标注空值，在表记录更新之后，一定记得清理空值标记缓存
     */
    public function get_table_by_key($table, $key, $value, $redis_key = "", $redis_expire = 300, $set_empty_flag = true) {
        $data = $this->get_redis($redis_key);
        if (!empty($data)) {
            if ($data == self::EMPTY_STRING) {
                return;
            } else {
                return unserialize($data);
            }
        }

        $data = $this->db->where($key, $value)->get($table)->row_array();
        $this->set_redis($redis_key, $data, $redis_expire, $set_empty_flag);

        return $data;
    }

    /**
     * 获取表数据
     * @param string table 表名
     * @param array where 查询条件
     * @param string redis_key redis 缓存键值, 可空， 非空时清理键值缓存
     * @param int redis_expire redis 缓存到期时长(秒)
     * @param boolean set_empty_flag 是否标注空值，如果标注空值，在表记录更新之后，一定记得清理空值标记缓存
     */
    public function get_table_data($table, $where = array(), $redis_key = "", $redis_expire = 600, $set_empty_flag = true) {
        $data = $this->get_redis($redis_key);
        if (!empty($data)) {
            if ($data == self::EMPTY_STRING) {
                return;
            } else {
                return unserialize($data);
            }
        }

        if (!empty($where)) {
            $data = $this->db->where($where)->get($table)->result_array();
        } else {
            $data = $this->db->get($table)->result_array();
        }

        $this->set_redis($redis_key, $data, $redis_expire, $set_empty_flag);

        return $data;
    }

    /**
     * 获取表数据（有序）
     * @param string table 表名
     * @param array where 查询条件
     * @param string order 排序
     * @param string limit 条目数
     * @param string redis_key redis 缓存键值, 可空， 非空时清理键值缓存
     * @param int redis_expire redis 缓存到期时长(秒)
     * @param boolean set_empty_flag 是否标注空值，如果标注空值，在表记录更新之后，一定记得清理空值标记缓存
     */
    public function get_table_data_order($table, $where, $order, $limit=0, $redis_key = "", $redis_expire = 600, $set_empty_flag = true) {
        $data = $this->get_redis($redis_key);
        if (!empty($data)) {
            if ($data == self::EMPTY_STRING) {
                return;
            } else {
                return unserialize($data);
            }
        }

        if (!empty($where)) {
            $data = $this->db->where($where)->order_by($order);
            if (!empty($limit)) {
                $data = $data->limit($limit);
            }
            $data = $data->get($table)->result_array();
        } else {
            $data = $this->db->order_by($order);
            if (!empty($limit)) {
                $data = $data->limit($limit);
            }
            $data = $data->get($table)->result_array();
        }

        $this->set_redis($redis_key, $data, $redis_expire, $set_empty_flag);

        return $data;
    }

    /**
     * 获取一条表数据
     * @param string table 表名
     * @param array where 查询条件
     * @param string redis_key redis 缓存键值, 可空， 非空时清理键值缓存
     * @param int redis_expire redis 缓存到期时长(秒)
     * @param boolean set_empty_flag 是否标注空值，如果标注空值，在表记录更新之后，一定记得清理空值标记缓存
     */
    public function get_one_table_data($table, $where, $redis_key = "", $redis_expire = 600, $set_empty_flag = true) {
        $data = $this->get_redis($redis_key);
        if (!empty($data)) {
            if ($data == self::EMPTY_STRING) {
                return;
            } else {
                return unserialize($data);
            }
        }

        if (!empty($where)) {
            $data = $this->db->where($where)->get($table)->row_array();
        } else {
            $data = $this->db->get($table)->row_array();
        }

        $this->set_redis($redis_key, $data, $redis_expire, $set_empty_flag);

        return $data;
    }

    /**
     * 获取表数据条数
     * @param string table 表名
     * @param array where 查询条件
     * @param string redis_key redis 缓存键值, 可空， 非空时清理键值缓存
     * @param int redis_expire redis 缓存到期时长(秒)
     */
    public function get_table_count($table, $where, $redis_key = "", $redis_expire = 600) {
        if (!empty($redis_key)) {
            $redis = Loader::redis("default");
            if (!empty($redis)) {
                $data = $redis->get($redis_key);
                if (!empty($data)) {
                    $cnt = intval($data) == self::EMPTY_STRING ? 0 : intval($data);
                    return intval($cnt);
                }
            }
        }

        $ret = $this->db->select('count(1) as cnt')
               ->where($where)
               ->get($table)
               ->row_array();

        $cnt = intval($ret['cnt']);

        if (!empty($redis_key) && !empty($redis)) {
            if ($cnt == 0) {
                $cnt = self::EMPTY_STRING;
            }
            $redis->set($redis_key, $cnt);
            $redis->expire($redis_key, $redis_expire);
        }

        return intval($ret['cnt']);
    }
}
