<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/********************************程序应用配置***************************************/
$config['test_conf'] = 'caohao';

return $config;