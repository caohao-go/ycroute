<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/*********************************** 常量定义*****************************************/

