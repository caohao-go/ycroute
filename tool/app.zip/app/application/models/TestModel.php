<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * ExampleModel Class
 *
 * @package        SuperCI
 * @subpackage    Model
 * @category      Example Model
 * @author        caohao
 */
class TestModel extends Core_Model {
    public function __construct() {
        $this->db = Loader::database('default');
    }
    
}