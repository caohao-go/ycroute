<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 *  UserController Class
 *
 * @package       SuperCI
 * @subpackage    Controller
 * @category      UserController
 * @author        caohao
 */
class TestController extends Core_Controller
{
    public function init()
    {
        parent::init();

        //业务层
        $this->test_business = Loader::model('TestModel');

        //日志
        $this->logger = Logger::get_instance('user_log');

        //公共函数
        Loader::helper('common_helper');

        $this->util_log = Logger::get_instance('user_log');
        Loader::helper('common_helper');
    }
    
    //用户信息接口
    public function indexAction() {
		$m = $this->params['m'];
		
		$ret = $this->test_business->get_table_data('user_info_test', ['age' => 31]);
		
		$redis = Loader::redis('default');
		$redis->set('xxxx', serialize($ret));
		$redis->expire('xxxx', 3600);
		
		$result = unserialize($redis->get('xxxx'));
		
        $this->response_success($result);
    }
}
