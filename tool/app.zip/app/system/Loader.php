<?php
/**
 * Loader Class
 *
 * @package        SuperCI
 * @subpackage    Libraries
 * @category      Loader
 * @author        caohao
 */
class Loader
{
    const REDIS_TYPE_MASTER = "master";
    const REDIS_TYPE_SLAVE = "slave";
		
    private static $configs = array();
    private static $has_helpers = array();
    private static $redis = array();
    
    private static $instance;

    public static function & get_instance() {
        if(empty(self::$instance)) {
            self::$instance = new Util_Loader();
        }
        
        return self::$instance;
    }
    
    public static function & config($conf_name) {
        if(isset(self::$configs[$conf_name])) {
            return self::$configs[$conf_name];
        }
        
        $path = Yaf_Registry::get("config")->application->appconf->directory;
        self::$configs[$conf_name] = include("$path/".$conf_name.".php");
        return self::$configs[$conf_name];
    }
    
    public static function helper($helper_name) {
        
        if (isset(self::$has_helpers[$helper_name])){
            return true;
        }
        
        $path = Yaf_Registry::get("config")->application->helper->directory;
        if (file_exists($path . "/" . $helper_name . ".php")){
            include_once($path . "/" . $helper_name . ".php");
            self::$has_helpers[$helper_name] = true;
        } else {
            self::$has_helpers[$helper_name] = false;
        }
        
        return true;
    }
    
    public static function library($library_name, $params = null) {
        if(!Yaf_Registry::has($library_name)) {
            $file_name = APPPATH . "/application/library/" . implode('/', explode('_', $library_name)) . ".php";
            include_once($file_name);
            if(empty($params)) {
                Yaf_Registry::set($library_name, new $library_name());
            } else {
                Yaf_Registry::set($library_name, new $library_name($params));
            }
        }
        
        return Yaf_Registry::get($library_name);
    }

    public static function model($business_name, $params = null) {
        if(!Yaf_Registry::has($business_name)) {
            $file_name = APPPATH . "/application/models/" . $business_name . ".php";
            include_once($file_name);
            
            if(empty($params)) {
                Yaf_Registry::set($business_name, new $business_name());
            } else {
                Yaf_Registry::set($business_name, new $business_name($params));
            }
        }

        return Yaf_Registry::get($business_name);
    }
    
    public static function database($params = '', $type = self::REDIS_TYPE_MASTER, $return = true, $use_phalcon = true)
    {
        global $CI_DATABASES;
        
        require_once(BASEPATH.'/database/DB.php');
        
        $key = $params . "_" . $type;
        
        if(!isset($CI_DATABASES[$key]))
        {
            $CI_DATABASES[$key] = DB($params, $type, $use_phalcon);
        }
        
        if ($return == true)
        {
            return $CI_DATABASES[$key];
        }
    }

    public static function & redis($redis_name, $type = self::REDIS_TYPE_MASTER, $reconnect = false) {
        $redis_instance_name = $redis_name . "_" . $type;
        if(empty(self::$redis[$redis_instance_name]) || $reconnect) {
            unset(self::$redis[$redis_instance_name]);
            $util_log = Logger::get_instance('loader_redis');
            
            $redis_config = self::config("redis")[$redis_name][$type];
            if(empty($redis_config)) {
                $util_log->LogError("Loader::redis:  redis config not exist");
                return;
            }
            
            self::$redis[$redis_instance_name] = new Redis();

            if(substr($redis_config['host'], 0, 1) == '/') {
                $flag = self::$redis[$redis_instance_name]->connect($redis_config['host']);
            } else {
                $flag = self::$redis[$redis_instance_name]->connect($redis_config['host'], $redis_config['port']);
            }

            if(!$flag) {
                $util_log->LogError("Loader::redis:  redis connect error");
                return;
            }
            
            if(!empty($redis_config['auth'])){
                $suc = self::$redis[$redis_instance_name]->auth($redis_config['auth']);
                if(!$suc) {
                    $util_log->LogError("Loader::redis:  redis auth error");
                    return;
                }
            }
        }
        return self::$redis[$redis_instance_name];
    }
}
